package com.jspiders.hibernate.dto;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Data
@Entity

public class MovieDto {
	@Id
	private int id;
	private String MovieName;
	private String Director;
	private String Category;
	

}
