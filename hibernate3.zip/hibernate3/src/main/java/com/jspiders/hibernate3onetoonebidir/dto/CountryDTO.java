package com.jspiders.hibernate3onetoonebidir.dto;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import lombok.Data;

@Data
@Entity

public class CountryDTO {
	@Id
	private int id;
	private String CountryName;
	private long Area;
	
	@OneToOne
	private CapitalDTO countryCapital;
}
