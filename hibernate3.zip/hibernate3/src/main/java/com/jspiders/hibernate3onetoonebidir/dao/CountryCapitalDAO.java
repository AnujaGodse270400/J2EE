package com.jspiders.hibernate3onetoonebidir.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.jspiders.hibernate3onetoonebidir.dto.CapitalDTO;
import com.jspiders.hibernate3onetoonebidir.dto.CountryDTO;



public class CountryCapitalDAO {

	private static EntityManagerFactory entityManagerFactory;
	private static EntityManager entityManager;
	private static EntityTransaction entityTransaction;
	
	private static void openConnection() {
		
		entityManagerFactory=Persistence.createEntityManagerFactory("country");
		entityManager=entityManagerFactory.createEntityManager();
		entityTransaction=entityManager.getTransaction();
		
	}
	
	private static void closeConnection(){
		if(entityManagerFactory != null) {
			entityManagerFactory.close();
		}
		if(entityManager != null) {
			entityManager.close();
		}
		if(entityTransaction.isActive()) {
			entityTransaction.rollback();
		}
	}
	public static void main(String[] args) {
		try {
			openConnection();
			
			entityTransaction.begin();
			
			CountryDTO country1=new CountryDTO();
			country1.setId(2);
			country1.setCountryName("dkfl");
			country1.setArea(4859480452L);
			
			CapitalDTO capital1=new CapitalDTO();
			capital1.setId(1);
			capital1.setCapitalName("dkjfkj");
			
			country1.setCountryCapital(capital1);
			capital1.setCapitalCountry(country1);
			
			entityManager.persist(country1);
			entityManager.persist(capital1);
			
						
			
			entityTransaction.commit();
		}
	
		finally {
			closeConnection();
		}
	}

}
