package com.jspiders.hibernate3onetoonebidir.dto;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import lombok.Data;

@Data
@Entity
public class CapitalDTO {
	@Id
	private int id;
	private String CapitalName;
	@OneToOne
	private CountryDTO capitalCountry;
}
