package com.jspiders.hibernate2onetoone.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.jspiders.hibernate2onetoone.dto.CapitalDTO;
import com.jspiders.hibernate2onetoone.dto.CountryDTO;


public class CountryCapitalDAO {

	private static EntityManagerFactory entityManagerFactory;
	private static EntityManager entityManager;
	private static EntityTransaction entityTransaction;
	
	private static void openConnection() {
		
		entityManagerFactory=Persistence.createEntityManagerFactory("capital");
		entityManager=entityManagerFactory.createEntityManager();
		entityTransaction=entityManager.getTransaction();
		
	}
	
	private static void closeConnection(){
		if(entityManagerFactory != null) {
			entityManagerFactory.close();
		}
		if(entityManager != null) {
			entityManager.close();
		}
		if(entityTransaction.isActive()) {
			entityTransaction.rollback();
		}
	}
	public static void main(String[] args) {
		try {
			openConnection();
			
			entityTransaction.begin();
			
			CountryDTO country1=new CountryDTO();
			country1.setId(1);
			country1.setCountryName("India");
			country1.setCountryArea(6473892002L);
			
			entityManager.persist(country1);
			
			CapitalDTO capital1=new CapitalDTO();
			capital1.setId(1);
			capital1.setCapitalName("Delhi");
			capital1.setCountry(country1);
			entityManager.persist(capital1);
						
			
			entityTransaction.commit();
		}
	
		finally {
			closeConnection();
		}
	}

}
